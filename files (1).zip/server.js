const express = require('express');
const app = express();
app.use(express.static(__dirname));

app.get('/healthz', (req, res) => res.send('ok'));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log('kids site listening on ' + port));
